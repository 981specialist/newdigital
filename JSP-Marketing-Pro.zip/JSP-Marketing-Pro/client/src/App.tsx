import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Contact from "@/pages/Contact";
import Blog from "@/pages/Blog";
import Reviews from "@/pages/Reviews";
import Legal from "@/pages/Legal";
import Terms from "@/pages/Terms";
import Accessibility from "@/pages/Accessibility";
import ServicePage from "@/pages/ServicePage";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/contact" component={Contact} />
      <Route path="/blog" component={Blog} />
      <Route path="/reviews" component={Reviews} />
      <Route path="/legal" component={Legal} />
      <Route path="/terms" component={Terms} />
      <Route path="/accessibility" component={Accessibility} />
      <Route path="/services/:slug" component={ServicePage} />
      <Route path="/design/:slug" component={ServicePage} />
      <Route path="/marketing/:slug" component={ServicePage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
